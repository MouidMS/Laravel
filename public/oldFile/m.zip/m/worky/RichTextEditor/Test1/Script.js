const elements = document.querySelectorAll(" .btn");

let content = document.getElementById("content");
elements.forEach(element => {
    element.addEventListener("click", (e) =>{
        let command = element.dataset["element"];

        if (command == "foreColor" || command == "fontName" || command == "fontSize" || command == "backColor" || command == "insertHTML" || command == "insertText" ) {
            let url = prompt();
            document.execCommand(command,false,url)
            
        }else if(command == "formatBlock"){
            document.execCommand(command,false,"p");
            let x = window.getSelection().focusNode.parentNode;
            x.classList.add('hh');
        }else if(command == "test1"){
            try {
                
                console.log(window.getSelection().getRangeAt(0).commonAncestorContainer.childNodes[1].innerText = window.getSelection().getRangeAt(0).commonAncestorContainer.childNodes[1].innerText.toLowerCase() )        
            } catch (error) {
                console.log("hh")
            }
        }else if(command == "test2"){
            console.dir(content)
        }else if(command == "test3"){
            document.execCommand('insertHTML',false,'<hr/>')        
        }else if(command == "test4"){

            console.log(window.getSelection().focusNode)
            console.log(window.getSelection().getRangeAt(0))
            let x = window.getSelection().getRangeAt(0).commonAncestorContainer.parentElement;
          while(x.classList[0] !== "kk"){
            console.log(x.className)
            console.log(x.tagName);
            x = x.parentElement;
            
          }
          
        } else {
            
        document.execCommand(command,false,null);
        }

    
        
    })

});





let sours = document.getElementById("htmlcontent");

let ff = true;
content.classList.add("lined")
// content.classList.remove("lined")

console.log(content)
function funhtml() {
sours.innerText = content.innerHTML;
};


        



// let test = document.createElement("div");

// test.style.backgroundColor = "red";
// test.style.width = "100px";
// test.style.height = "100px";
// test.style.borderColor = "black";
// test.style.borderStyle = "solid";

// // sours.appendChild(test);
// console.log("===============");
// console.log(test);

// let date = {
//     name: "hh",
//     age: 99,
// }

// let x = JSON.parse(date);
// console.log(x);
// // sours.textContent =  JSON.stringify(tets.);


// console.log("===============");