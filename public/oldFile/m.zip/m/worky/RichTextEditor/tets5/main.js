import Container from './Container.js';
import Edit from './BasicEdit.js';
import ComponentList from './ComponentList.js';
import PageEdit from './PageEdit.js';
import {countries} from './Countries.js';
import { currentComponent } from './Component.js';
import { currentPage } from './Page.js';
import CompomnentBtn from './ComponentBtn.js';


export let isFullPreemption = true;



let resizer = document.getElementById('slider');
export let leftSide = document.getElementById('main-content');
let rightSide = document.getElementById('reading');


let textEdit = document.getElementById("TextEditContainer"); 


let setting = document.getElementById('setting');
let settingbtn = document.getElementById('settingbtn');
let Back = document.getElementById('Back');
let Display = document.getElementById('Display');
let Save = document.getElementById('Save');

export const translateFrom = document.getElementById('translateFrom');
export const swichlang = document.getElementById('swichlang');
export const translateTO = document.getElementById('translateTO');


export let pageParent = document.getElementById('pages');
let addPage = document.getElementById('addpage');


export let borderStyle = ["solid","dotted","dashed","outset","double","groove","inset","ridge"];
export let pagePostion = ["none","top","top-right","top-left","bottom","bottom-right","bottom-left"];
export let border = ["Border/Raduis","Top/top-left","Right/top-right","Buttom/buttom-right","Left/buttom-left"];
export let textSpacing = ["normal",1,2,3,4,5,6,7,8,9,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120]
export let iconList = [["none","none"],["fa-solid fa-house","&#xf015"],["fa-brands fa-facebook","&#xf09a"],["fa-brands fa-tiktok","&#xe07b"],["fa-brands fa-instagram","&#xf16d"],["fa-brands fa-twitter","&#xf099"],["fa-solid fa-location-dot","&#xf3c5"],["fa-brands fa-github","&#xf09b"]]
export let backDesign = ["none"];
export let borderDesign = ["none"];
export let listStyles = ["disc","none","circle","square","decimal","decimal-leading-zero","lower-alpha","lower-greek","lower-latin","lower-roman","upper-alpha","upper-greek","upper-latin","upper-roman","armenian","cjk-ideographic","georgian","hebrew","hiragana","hiragana-iroha","katakana","katakana-iroha"];
export let componentList = new ComponentList();
export let pageEdit = new PageEdit();
export let compomnentBtn = new CompomnentBtn();




export let container = new Container();
addPage.addEventListener('click', () =>{
let current = container.addNewPage(container.getbackGrounColor(),container.getpageDesign(),
[container.getborderColor()[0],container.getborderColor()[1],container.getborderColor()[2],container.getborderColor()[3],container.getborderColor()[4]],
container.getborderDesign(),
[container.getborderStyle()[0],container.getborderStyle()[1],container.getborderStyle()[2],container.getborderStyle()[3],container.getborderStyle()[4]],
[container.getborderWidth()[0],container.getborderWidth()[1],container.getborderWidth()[2],container.getborderWidth()[3],container.getborderWidth()[4]],
[container.getborderRadius()[0],container.getborderRadius()[1],container.getborderRadius()[2],container.getborderRadius()[3],container.getborderRadius()[4]],
container.getPageNumber(),container.getpageNumberColor());

pageParent.appendChild(current);
current.scrollIntoView({behavior: "smooth"});
});
addPage.click();



        textEdit.addEventListener('mousedown', (e)=>{
                e.stopPropagation();
        });
        

        leftSide.addEventListener('scroll', (e) =>{
                textEdit.style.display = 'none';
        });

        window.addEventListener('mousedown', (e) =>{
            window.getSelection().removeAllRanges();
            textEdit.style.display = 'none';
            setting.style.display = 'none';
            addPage.style.transform = "rotate(0deg)";
            settingbtn.style.transitionDelay = "0.6s"
            Back.style.transitionDelay = "0.4s"
            Display.style.transitionDelay = "0.2s"
            Save.style.transitionDelay = "0s"
            settingbtn.style.left = `${40}px`;
            settingbtn.style.bottom = `${40}px`;
            Back.style.left = `${40}px`
            Back.style.bottom = `${40}px`
            Display.style.left = `${40}px`
            Display.style.bottom = `${40}px`
            Save.style.left = `${40}px`
            Save.style.bottom = `${40}px`
        }); 
            
            // if( (e.clientY <= leftSide.getBoundingClientRect().top + 300) ) {
                //     console.log("scrolltop")
                //     // worker.terminate()
                //     // worker.postMessage("bottom",leftSide);
                // }else{
                    //     console.log("unscroll")
                    // }
                
        let worker;
        export let scrollUp = document.getElementById('scrollUp')
        export let scrolldown = document.getElementById('scrolldown')
        scrollUp.addEventListener("mouseenter", (e)=>{
            startWorker();
            worker.postMessage("top");
        })
        scrolldown.addEventListener("mouseenter",(e)=>{
            startWorker();
            worker.postMessage("bottom");
        })
        scrollUp.addEventListener("mouseleave",stopWorker)
        scrolldown.addEventListener("mouseleave",stopWorker)

        function startWorker() {
            if(typeof(Worker) !== "undefined") {
                if(typeof(worker) == "undefined") {
                    if (worker == undefined) {
                        console.log("gg")
                        worker = new Worker("./scroll.js");
                        worker.onmessage = function(masg){
                            
                            if (masg.data == "top") {
                                leftSide.scrollBy(0,-5);
                            } else {
                                leftSide.scrollBy(0,5);
                            }
                        }
                    }
                }
            } else {
            console.log("Sorry, your browser does not support Web Workers...");
            }
        };


        
        function stopWorker() { 
            worker.terminate();
            worker = undefined;
            console.log("leave")
        }

        
        
        window.addEventListener("keydown",(e)=>{
            if (currentComponent !== undefined) {
                if (e.shiftKey) {
                    if (e.keyCode == '38') {
                        e.preventDefault();
                        currentComponent.setYAxis(currentComponent.getYAxis()-1);
                    }
                    else if (e.keyCode == '40') {                    
                        e.preventDefault();
                        currentComponent.setYAxis(currentComponent.getYAxis()+1);
                    }
                    else if (e.keyCode == '37') {                    
                        e.preventDefault();
                        currentComponent.setXAxis(currentComponent.getXAxis()-1);
                    }
                    else if (e.keyCode == '39') {
                        e.preventDefault();
                        currentComponent.setXAxis(currentComponent.getXAxis()+1);
    
                    }
                }
                
                if (e.ctrlKey) {
                    if (e.keyCode == '38') {
                        e.preventDefault();
                        currentComponent.setHeight(currentComponent.getHeight()-1);
                    }
                    else if (e.keyCode == '40') {                    
                        e.preventDefault();
                        currentComponent.setHeight(currentComponent.getHeight()+1);
                    }
                    else if (e.keyCode == '37') {                    
                        e.preventDefault();
                        currentComponent.setWidth(currentComponent.getWidth()-1);
                    }
                    else if (e.keyCode == '39') {
                        e.preventDefault();
                        currentComponent.setWidth(currentComponent.getWidth()+1);
    
                    }
                }
            }
        
        });




        window.addEventListener('mouseup', (e) =>{
            
                let sel;
                try{sel = window.getSelection().getRangeAt(0).toString();}catch{}
                let rect = document.body.getBoundingClientRect();
                // console.log(window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0)
                if(e.which == 3){
                    // setTextEdit();
                    componentList.getAddComponentList().remove();
                        console.log('insertTectEdit//rightClick');
                        var addleft = e.clientX ;
                        var addright = e.clientY -120;
                        

                        if ((addleft + 400) > rect.width) {
                                addleft = addleft - (400 - (rect.width - e.clientX));
                        }
                        
                        if ((addright) <  0) {
                                addright = addright + 470;
                        }

                        if(e.clientY > document.documentElement.clientHeight/1.59){
                                addright = addright - 330;
                        }
                        
                        textEdit.style.left = `${addleft}px`;
                        textEdit.style.top = `${addright }px`;
                        textEdit.style.display = 'inline';      
                }else{
                        if (sel !== "" && sel !== undefined) {
                            // setTextEdit();
                            componentList.getAddComponentList().remove();
                                console.log('insertTectEdit//leftClick');
                                var addleft = e.clientX ;
                                var addright = e.clientY -120;
                                

                                if ((addleft + 400) > rect.width) {

                                        addleft = (addleft -(400));
                                }
                                
                                if ((addright) <  0) {
                                        addright = addright + 120;
                                }
                                
                                textEdit.style.left = `${addleft}px`;
                                textEdit.style.top = `${addright }px`;
                                textEdit.style.display = 'inline'; 
                        };
                };
        });











        function spack(){
            let text = window.getSelection().getRangeAt(0).toString();
            let utterannce = new SpeechSynthesisUtterance(text);
            console.log( window.speechSynthesis.getVoices())
            // utterannce.lang  = "ar-SA";
            // // utterannce.voice = "ar-SA";
        
           window.speechSynthesis.speak(utterannce);
        }



        
        
        let isrecog = true ;
        let contenuerecog;
        window.SpeechRecognition = window.SpeechRecognition || webkitSpeechRecognition;

        const recognition = new window.SpeechRecognition();
        recognition.interimResults = true;
        recognition.lang = translateFrom.value;
        
        recognition.addEventListener('result', (e) =>{
            const text = Array.from(e.results).map(result => result[0]).map(result => result.transcript).join('');
            if (e.results[0].isFinal) {
                console.log(text)
                document.execCommand('insertHTML',false,'&nbsp')
                document.execCommand('insertText',false,text);
                
            }
        })
        
        recognition.addEventListener('end', () =>{
            if (contenuerecog) {
                recognition.start();
            } else {
                recognition.stop();   
            }
        })

        

        let bold = document.getElementById("bold"); 
        let italic = document.getElementById("italic");
        let underline = document.getElementById("underline");
        let strikethrough = document.getElementById("strikethrough");
        let backColor = document.getElementById("backColor");
        let fontSize = document.getElementById("fontSize");
        let fontName = document.getElementById("fontName");
        let foreColor = document.getElementById("foreColor");
        let subscript = document.getElementById("subscript");
        let superscript = document.getElementById("superscript");     
        let toUpperCase = document.getElementById("toUpperCase");
        let toLowerCase = document.getElementById("toLowerCase");
        let createLink = document.getElementById("createLink");

        let translait = document.getElementById("translait");

        // document.querySelectorAll(".btn").forEach(element => {element.addEventListener("click",editText)});
        document.querySelectorAll(".change").forEach(element => {element.addEventListener("change",editText)});
        document.querySelectorAll(".btn").forEach(element => {element.addEventListener("mouseup",editText)});
        document.querySelectorAll(".change").forEach(element => {element.addEventListener("mouseup",(e)=>{e.stopPropagation();})})
        



function editText(e){

    e.stopPropagation();
    e.preventDefault();
    let command = this.dataset.element;
    let current = this.value;
    let sel =  window.getSelection().getRangeAt(0).toString();
    if(command == "backColor" || command == "fontSize" || command == "fontName" || command == "foreColor" ){
        document.execCommand(command,false,current);
    
    }else if(command == "voiceToText"){
        if (isrecog) {
            isrecog = false;
            contenuerecog = true;
            e.target.style.backgroundColor = "#aedada";
            recognition.lang = translateFrom.value;
            recognition.start();
        } else {
            isrecog = true;
            contenuerecog = false;
            e.target.style.backgroundColor = "#ffffff";
            recognition.stop();
        }
    }else if(command == "textToVoice"){
        spack();
    }else if(command == "textToVoiceTranslait"){
        
    }else if(command == "date"){
        var date_time = new Date().toLocaleString();
        document.execCommand("insertText",false,` “${date_time}” `);
    }else if(command == "toUpperCase"){
        document.execCommand("insertText",false,sel.toUpperCase());
    }else if(command == "toLowerCase"){
        document.execCommand("insertText",false,sel.toLowerCase());
    }else if(command == "readyTextDesign"){
        
    }else{ 
        document.execCommand(command,false,null);
    }

};


// translateFrom;
// translateTO
// swichlang
function setTextEdit(){
    let sel;
    try{sel = window.getSelection().getRangeAt(0).toString();}catch{}
    // let range = window.getSelection().getRangeAt(0);
    let rangeLength = window.getSelection().getRangeAt(0).commonAncestorContainer.childNodes.length;
    let current = window.getSelection().getRangeAt(0).commonAncestorContainer.parentElement;

    // if (rangeLength == 0) {

    //     while(current.classList[0] !== "editable"){
    //         current.tagName
    //         switch (current.tagName) {
    //             case "B":
    //                 bold.style.backgroundColor = "#e0e9ff";
    //             case "I":
    //                 italic.style.backgroundColor = "#ffffff";
    //             case "U":
    //                 underline.style.backgroundColor = "#ffffff";
    //             case "STRIKE":
    //                 strikethrough.style.backgroundColor = "#ffffff";
    //             case "FONT":
    //                 if (current.color !== "") {
    //                     foreColor.value = current.color;
    //                 } else if(current.face !== ""){
    //                     for (let index = 0; index <  fontName.children.length; index++) {
    //                         if ( fontName.children[index] == current.face) {
    //                             fontName.children[index].selected = true;
    //                             break;
    //                         }
                            
    //                     }
                        
    //                 }else if(current.size !== ""){
    //                     for (let index = 0; index <  fontSize.children.length; index++) {
    //                         if ( fontSize.children[index] == current.size) {
    //                             fontSize.children[index].selected = true;
    //                             break;
    //                         }
                            
    //                     }

    //                 }
    //             case "SUP":
    //                 superscript.style.backgroundColor = "#ffffff";
    //             case "SUB":
    //                 subscript.style.backgroundColor = "#ffffff";
    //             case "SPAN":
    //                 if (current.style.backgroundColor !== "") {
                        
    //                     backColor.value = current.style.backgroundColor;
    //                 } 

    //             case "DIV":

    //             case "A":
    //                 createLink.style.backgroundColor = "#ffffff";
    //         }
    //         current =  current.parentElement;
            
    //     }
    //     console.log (current.className)

    // //     d
    // //     bold e0e9ff
    // //     italic
    // //     underline
    // //     strikethrough
    // //     backColor
    // //     for (let index = 0; index < fontSize.children.length; index++) {
    // //         if (fontSize.children[index] == "") {
    // //             fontSize.children[index].selected = true;
    // //         }
            
    // //     }
    // //     fontSize Arial
    // //     fontName
    // //     foreColor
    // //     subscript
    // //     superscript
    // //     createLink

    // //     toUpperCase
    // //     toLowerCase
    // } else {
    //     bold.style.backgroundColor = "#ffffff";
    //     italic.style.backgroundColor = "#ffffff";
    //     underline.style.backgroundColor = "#ffffff";
    //     strikethrough.style.backgroundColor = "#ffffff";
    //     backColor.value = "#000000";
    //     fontSize.children[0].selected = true; 
    //     fontName.children[0].selected = true;
    //     foreColor.value = "#000000";
    //     subscript.style.backgroundColor = "#ffffff";
    //     superscript.style.backgroundColor = "#ffffff";
    //     toUpperCase.style.backgroundColor = "#ffffff";
    //     toLowerCase.style.backgroundColor = "#ffffff";
    //     createLink.style.backgroundColor = "#ffffff";
        
    // }
}


function removeSelation(){
    window.getSelection().removeAllRanges();
    textEdit.style.display = 'none';
}



for(const country_code in countries){
    let selected;
    if (country_code == 'en-GB') {
        selected = "selected";
    }
    let option = `<option value="${country_code}" ${selected}>${countries[country_code]}</option>`
    translateFrom.insertAdjacentHTML("beforeend", option);
}

for(const country_code in countries){
    let selected;
    if (country_code == 'ar-SA') {
        selected = "selected";
    }
    let option = `<option value="${country_code}" ${selected}>${countries[country_code]}</option>`
    translateTO.insertAdjacentHTML("beforeend", option);
}
function Translait(text,from,to){
    let translaitedtext;
    console.log(`${text}${from}${to}`);
    let apiUrl = `https://api.mymemory.translated.net/get?q=${text}&langpair=${from}|${to}`;
    fetch(apiUrl).then(res => res.json()).then(data =>{
        console.log(data)
        translait.innerText = data.responseData.translatedText;
    })
    

}


setting.addEventListener('mousedown',(e) =>{
    e.stopPropagation()
})
settingbtn.addEventListener('mousedown',(e) =>{
    e.stopPropagation();
    setting.style.display == 'none'? setting.style.display = 'inline' : setting.style.display = 'none';
})
addPage.addEventListener('mouseover', (e) =>{
    removeSelation();
    addPage.style.transform = "rotate(360deg)";
    settingbtn.style.transitionDelay = "0s"
    Back.style.transitionDelay = "0.2s"
    Display.style.transitionDelay = "0.4s"
    Save.style.transitionDelay = "0.6s"
    settingbtn.style.left = `${15}px`;
    settingbtn.style.bottom = `${110}px`;
    Back.style.left = `${65}px`
    Back.style.bottom = `${100}px`
    Display.style.left = `${100}px`
    Display.style.bottom = `${65}px`
    Save.style.left = `${110}px`
    Save.style.bottom = `${15}px`
});

// 1
// 1
// 1
// 1

// 1
// 1
// 1
// 1
// 1
// 1
// 1
// 1
// 1

let print = document.getElementById('print');

// print.addEventListener('click', printDiv);
let leftSideWidth = 90;

let showReadingSec = document.getElementById('showReadingSec');
let uploadFile = document.getElementById('uploadFile');
let frame = document.getElementById('frame');
let readingFiles = document.getElementById('readingFiles');
let deleteFile = document.getElementById('deleteFile');

showReadingSec.addEventListener('change', (e)=>{
    if (showReadingSec.checked == true ){
        resizer.style.display = 'inline';
        rightSide.style.display = 'inline';
        leftSideWidth = 90;
        leftSide.style.width = '80%';
        
    } else {
        resizer.style.display = 'none';
        rightSide.style.display = 'none';
        leftSideWidth = 100;
        leftSide.style.width = '100%';
        
    }
    scrolerChange();
});

new Sortable(readingFiles,{
    animation: 350
});

let currentFile;
frame.addEventListener("scroll",(e)=>{
    currentFile.dataset.height = window.pageYOffset || document.documentElement.scrollTop || 0;
})


uploadFile.addEventListener('change', function(){
    
    const filereader = new FileReader();
    
    filereader.addEventListener('load', () => {
        
        let filename = this.files[0].name;
      
        filename =  filename.trim();
        filename = filename.replace(/\s+/g,'');
        filename =  filename.replace(/.pdf/,'');
        renderPDF(filereader.result);
        addNewFile(filereader.result,0,filename);
    });
    filereader.readAsDataURL(this.files[0]);


});

function renderPDF(url){
    if (frame.children.length > 0) {
        frame.children[0].remove();
    }
    let curent = document.createElement('div');
    curent.classList.add('pdfViwer');
    frame.appendChild(curent);
    PDFObject.embed(url,curent);
}

function addNewFile(url,height,name,id){
 
    let current = document.createElement('span');
    current.classList.add('fileContainer');
    current.dataset.url = url;
    current.dataset.height = height;
    current.dataset.id = id;
    current.innerText = name;
    current.addEventListener('click', dispalyFile);
    readingFiles.appendChild(current);
    currentFile = current

}


const dispalyFile = (e) =>{
    currentFile.style.border = 'none';
    currentFile = e.target

    PDFObject.embed(currentFile.dataset.url,frame);
    // let x = document.getElementsByClassName('pdfobject')[0];
    // x.zoom = 200;
    currentFile.style.border = '1px solid';

}

deleteFile.addEventListener('click', (e)=>{
    for (let index = 0; index < readingFiles.children.length; index++) {
        console.log(readingFiles.children[index].innerText);
        
    }
})






let scroler = document.getElementById('scroler');

leftSide.addEventListener('scroll', (e)=>{ scrolerChange()});


function scrolerChange(){
    let height =  leftSide.scrollHeight - leftSide.clientHeight;
    let scrolltop = leftSide.scrollTop ;
    scroler.style.width = `${(scrolltop/height) * leftSideWidth}%`;
}





// function printDiv() {
    
//     var a = window.open('', '',);
//     a.document.write('<html>');
//     a.document.write('<body > <h1>Div contents are <br>');
//     for (let index = 0; index < pageParent.children.length; index++) {
//         a.document.write(pageParent.innerHTML);    
//     }
//     a.document.write('</body></html>');
//     a.document.close();
//     a.print();

// }




        resizer.addEventListener('mousedown', mouseDownHandler);

        let x = 0;
        let y = 0
        let leftWidth = 0;

        function mouseDownHandler (e){
            x = e.clientX;
            y = e.clientY;
            leftWidth = leftSide.getBoundingClientRect().width;

            document.addEventListener('mousemove', mouseMoveHandler);
            document.addEventListener('mouseup', mouseUpHandler);


        };

        function mouseMoveHandler(e){
            const dx = e.clientX - x;
            const dy = e.clientY - y;

            const newLeftWidth = ((leftWidth + dx)* 100)/ resizer.parentNode.getBoundingClientRect().width;
            if (newLeftWidth <= 90 && newLeftWidth >= 20) {
                leftSideWidth = newLeftWidth;
                leftSide.style.width = `${newLeftWidth}%`;
                scrolerChange();
            };
            
            resizer.style.cursor = 'col-resize';
                document.body.style.cursor = 'col-resize';

                leftSide.style.userSelect = 'none';
                leftSide.style.pointerEvents = 'none';

                rightSide.style.userSelect = 'none';
                rightSide.style.pointerEvents = 'none'
        }

        function mouseUpHandler(){
            resizer.style.removeProperty('cursor');
                document.body.style.removeProperty('cursor');

                leftSide.style.removeProperty('user-select');
                leftSide.style.removeProperty('pointer-events');

                rightSide.style.removeProperty('user-select');
                rightSide.style.removeProperty('pointer-events');
            document.removeEventListener('mousemove', mouseMoveHandler);
                document.removeEventListener('mouseup', mouseUpHandler);
        }

     

        let json = document.getElementById('test');
        json.addEventListener('click',(e)=>{
            readJsonOpj(JSON.stringify(container.getPages()))})

        // let imageContainer = document.getElementById('imageContainer');
        // let addUrl = document.getElementById('addUrl');
        // let uploadImage = document.getElementById('uploadImage');
        // let addImageToList = document.getElementById('addImageToList');
        // let deleteImageFromList = document.getElementById('deleteImageFromList');
        // let imageList = document.getElementById('imageList');
        // let OK = document.getElementById('OK');
        // let cansel = document.getElementById('cansel');

        // addImageToList.addEventListener("click",(e)=>{
        //     e.preventDefault();
        //     fetch('upload-image.php',{
        //         method : "POST",
        //         body : new FormData(imageContainer)
        //     })
        // })
        // deleteImageFromList.addEventListener("click",(e)=>{

        // })
        // OK.addEventListener("click",(e)=>{

        // })
        // cansel.addEventListener("click",(e)=>{

        // })


        // uploadImage.addEventListener('change', function(){
        //     const reader = new FileReader();
        //     reader.addEventListener('load', () => {
        //         // let gg = reader.result;
        //         console.log(reader.result);
                
        //     });
        //     reader.readAsDataURL(this.files[0]);

        // });

        // element["backGrounColor"]
        function readJsonOpj(jsonOpj){
            let pages = JSON.parse(jsonOpj);

            //backGrounColor,pageDesign,borderColor,borderDesign,borderStyle,borderWidth,borderRadius,pageNumber,pageNumberColor
            pages.forEach(element => {
                
                let current = container.addNewPage(element['backGrounColor'],element["pageDesign"],
                    [element["borderColor"][0],element["borderColor"][1],element["borderColor"][2],element["borderColor"][3],element["borderColor"][4]],
                    element["borderDesign"],
                    [element["borderStyle"][0],element["borderStyle"][1],element["borderStyle"][2],element["borderStyle"][3],element["borderStyle"][4]],
                    [element["borderWidth"][0],element["borderWidth"][1],element["borderWidth"][2],element["borderWidth"][3],element["borderWidth"][4]],
                    [element["borderRadius"][0],element["borderRadius"][1],element["borderRadius"][2],element["borderRadius"][3],element["borderRadius"][4]],
                    element["pageNumber"],element["pageNumberColor"]);
    
                pageParent.appendChild(current);
            });
            
        }


        let db;
        const openRequest = window.indexedDB.open("jsonOpj",1);

        openRequest.addEventListener('error', ()=>{
            console.error("Database failed to open")
        });

        openRequest.addEventListener('success', ()=>{
            console.log("Database opened successfully");
            
            db = openRequest.result;

            // displayData();
        });

        openRequest.addEventListener('upgradeneeded', (e)=>{
            db = e.target.result;

            const objectStore = db.createObjectStore("jsonOpj", {
                keyPath: "id",
                autoIncrement: true,
            });

            objectStore.createIndex("jsonopject", "jsonopject", { unique: false });
            objectStore.createIndex("lastupdate", "lastupdate", { unique: false });

            console.log("Database setup complete");
        });



        window.addEventListener('load', prepairPage);

        function prepairPage(e){

        }

        setInterval(upDataLoculjson, 60*1000);

        window.addEventListener('unload', upDataLoculjson);

        function upDataLoculjson(){
            console.log("data updated")
        }
        

        function addLoculjson(data,lastupdate){

            e.preventDefault();
            const newItem = { jsonopject: data, lastupdate: lastupdate};
            const transaction = db.transaction(["jsonOpj"], "readwrite");
            const objectStore = transaction.objectStore("jsonOpj");
            const addRequest = objectStore.add(newItem);

            addRequest.addEventListener("success", () => {
                console.log("success.");
            });

            transaction.addEventListener("complete", () => {
                console.log("Transaction completed: database modification finished.");
                displayData();
            });

            transaction.addEventListener("error", () =>
                console.log("Transaction not opened due to error")
            );

            console.log("data added")
        }



        function clearLoculjson(){
            console.log("data cleared")
        }




