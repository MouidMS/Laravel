import ParentComponent from "./ParentComponent.js";
import {compomnentBtn,isFullPreemption} from "./main.js";
import { currentComponent,setCurrentComponent} from "./Component.js";
import { compInFlag } from "./ParentComponent.js";


export default class Paragraph extends ParentComponent{

    start;
    styleType;
    itemSpace;

    constructor(start,styleType,itemSpace,width,height,xAxis,yAxis,zAxis,opacity,rotation,padding,skew,backGrounColor,backGrounDesign,borderColor,borderDesign,borderStyle,borderWidth,borderRadius,polygon,isSizesEditable,isDesignEditable,isContentEditable){
        super(width,height,xAxis,yAxis,zAxis,opacity,rotation,padding,skew,backGrounColor,backGrounDesign,borderColor,borderDesign,borderStyle,borderWidth,borderRadius,polygon,isSizesEditable,isDesignEditable,isContentEditable);   
        this.setCompomnent(this.prepairComponent());
        this.applyparentComponentEdites();
        this.applyComponentEdit();
        this.setStart(start);
        this.setStyleType(styleType);
        this.setItemSpace(itemSpace);
        console.log('List');
    };

    prepairComponent(){
        let comp = document.createElement('ol');
        comp.classList.add('list');
        comp.classList.add('component');
        if (isFullPreemption) {
        } else {
            if (this.getIsContentEditable()) {
            } 
        }
        let current = document.createElement('div');
        current.classList.add('parentComponent');
        current.appendChild(comp);
        return comp;
    };


    setStart(value){
        this.start = start;
    }
    setStyleType(value){
        this.styleType = styleType;
    }
    setItemSpace(value){
        this.itemSpace = value;
    }

    compomnentIn = (e) =>{
        if (compInFlag) {
            console.log('componentIn');
            setCurrentComponent(this);
            this.addControlBtn();
            compomnentBtn.prepairListEdit(this.getStart(),this.getStyleType(),this.getItemSpace(),
                this.getWidth(),this.getHeight(),this.getXAxis(),
            this.getYAxis(),this.getZAxis(),this.getOpacity(),this.getRotation(),this.getPadding(),this.getskew(),this.getBackGrounColor(),this.getBackGrounDesign(),this.getBorderColor(),this.getBorderDesign(),
            this.getBorderStyle(),this.getBorderWidth(),this.getBorderRadius(),this.getpolygon(),this.getIsContentEditable(),this.getIsDesignEditable(),this.getIsSizesEditable());
            this.getCompomnent().parentNode.appendChild(compomnentBtn.getEditContainer());
        }
    }
    

    getStart(){
        return this.start;
    }
    getStyleType(){
        return this.styleType;
    }
    getItemSpace(){
        return this.itemSpace;
    }

    addEvents(){
        this.getCompomnent().addEventListener("click",this.compomnentIn);
    }

    removeComponentFormat(){
        
        this.setStart(0);
        this.styleType();
        this.setItemSpace(0);
        this.setOpacity(1)
        this.setZAxis(0)
        this.setRotation(0)
        this.setPadding(0);
        this.setSkew(0);
        this.setBackGrounColor("#ffffff",0)
        this.setBackGrounDesign("none")
        this.setBorderColor("#000000")
        this.setBorderDesign("none")
        this.setBorderStyle("solid",0)
        this.setBorderWidth(0,0)
        this.setBorderRadius(0,0)
        this.setPolygon("none")
    }
}