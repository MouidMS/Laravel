import Page from './Page.js';
import { container } from './main.js';

export default class A4Page extends Page{

    constructor(){
        // backGrounColor,pageDesign,borderColor,borderDesign,borderStyle,borderWidth,borderRadius,pageNumber,pageNumberColor
        super();
        
    };
    
}