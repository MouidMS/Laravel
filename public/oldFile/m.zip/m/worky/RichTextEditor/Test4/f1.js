// console.log("ff");


// let vx =10;

// export default class gg{
//     a1;
//     a2;
//     a3;
//     constructor(){
//         this.a1 = 1;
//         this.a2 = 2;
//         this.a3 = document.createElement('button'); 
//     }

// }

// class g{
//         constructor(x){
//             this.x = x;
//         }
//     }

let x = document.getElementById('jj');

// let e = [];
// let c;
// for (let index = 0; index < 7; index++) {
//     c = document.createElement('div');
//     c.classList.add('gg');
//     c.innerText = `${index}`
//     e.push(c);
//     x.appendChild(c);    
// }

// x.children[5].innerText = "hh"

// console.log("===============");
// for (let index = 0; index < x.children.length; index++) {
//     console.log(x.children[index].innerText);
    
// }

// for (let index = 0; index < x.children.length; index++) {
//     console.log(x.children[index] == e[index]);
    
// }


// console.log("/////////////");
// for (let index = 0; index < x.children.length; index++) {
//     x.children[index].addEventListener('click', (e) =>{
//         console.log(e.target)
//         delet(e.target);
//     })
    
// }

console.log("/////////////");



function up(i){
        let ch = e[i];
        e[i] = e[i - 1];
        e[i - 1] = ch;


        x.children[i].parentNode.insertBefore(x.children[i], x.children[i - 1]) ;

}

function down(i){
    let ch = e[i];
        e[i] = e[i + 1];
        e[i + 1] = ch;


        x.children[i].parentNode.insertBefore(x.children[i + 1], x.children[i]) ;

}

function delet(i){
    e.splice(e.indexOf(i),1);
    x.removeChild(i);
    for (let index = 0; index < x.children.length; index++) {
        console.log(x.children[index].innerText);
        
    }
    console.log(e.length)
    
}

function dub(i){
    let current = i.cloneNode(true);
    current.addEventListener('click', (e) =>{
        console.log(e.target)
        dub(e.target);
    })
    console.log(current)
    e.push(current);
    x.appendChild(current);


}




// let y = document.getElementById('ll');

// x.addEventListener('click', ff);

// function ff(e){
//     let rect = e.target.getBoundingClientRect();
    
//     var addleft = (((e.clientX - rect.left)/rect.width)*100);
//     var addright = (((e.clientY - rect.top)/rect.height)*100)
//     y.style.left = `${addleft}%`;
//     y.style.top = `${addright}%`;
//     console.log(`${addleft}//${addright}//${rect.width}`)
//     console.log(e.target)
// }

// x.style.borderBlockColor = "#jjjjjj";
// x.style.borderWidth = "1px"
// x.style.borderStyle

// let y = document.createElement('div');
// let z = document.createElement('div');

// y.id = 'kk';
// z.id = 'zz';
// x.appendChild(y);
// x.appendChild(z);

// x.addEventListener('mouseenter', g1);
// x.addEventListener('mouseout', g2);
// function g1 (e) {

//     if (!x.contains(e.relatedTarget )) {
        
//         console.log("enter");
//     }

// }


// function g2 (e) {
//     if (!x.contains(e.relatedTarget )) {
        
//         console.log("out");
//     }
// }

// let x = document.getElementById('borderstyle');
// x.addEventListener('change',() =>{
//     console.log(x.value)
// })

// x.children[6].selected = 'true';
// console.log(x.value)
// x.children[8].selected = 'true';

// let x = document.getElementById('pageEdit');

// for (let index = 0; index < x.children.length; index++) {
//     console.log(x.children[index].id)
    
// }

  





