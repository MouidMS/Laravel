const elements = document.querySelectorAll(".btn");


elements.forEach(element => {
    element.addEventListener("click", () =>{
        let command = element.dataset["element"];

        if (command == "foreColor" || command == "fontName" || command == "fontSize" || command == "backColor") {
            let url = prompt();
            document.execCommand(command,false,url)
            
        } else {
            
        document.execCommand(command,false,null);
        }

    })
});

let sours = document.getElementById("htmlcontent");
let content = document.getElementById("content");

function funhtml() {
sours.textContent = content.innerHTML;
};
