<?php
class Car {
  public $name;
  public $color;

  function __construct($name) {
    $this->name = $name;
  }
  function get_name() {
    return $this->name;
  }
  function get_color() {
    return $this->color;
  }
}
$mycar = new Car("Audi");
$mycar->color = "red";

echo $mycar->get_name(); // Audi
echo $mycar->get_color(); // red