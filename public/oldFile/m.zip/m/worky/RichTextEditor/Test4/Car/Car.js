class Car{
    name;
    color;

    constructor(name) {
    this.name = name;
    }

    get_name() {
        return this.name;
    }

    get_color() {
        return this.color;
    }
}
mycar = new Car("Audi");
mycar.color = "red";

console.log(mycar.get_name()); // Audi
console.log(mycar.get_color()) ; // red