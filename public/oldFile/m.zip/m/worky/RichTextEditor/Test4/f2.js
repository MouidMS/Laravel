// import gg from "./f1.js";

// let x = document.getElementById('gg');
// let hh = new gg();

// hh.a1 = 65;


// let jj = new gg();
// console.log(jj);

// let ff = hh;

// let kk = Object.create(hh);
// kk.a3 = hh.a3.cloneNode(true);
// console.log(hh);
// console.log(kk);
// kk.a1 = 99;
// console.log(hh);
// console.log(kk);



// x.appendChild(hh.a3);
// x.appendChild(jj.a3);

// x.appendChild(kk .a3);

// console.log(kk.a3 == hh.a3)


class A{
    a1;
    a4;
    constructor(a4){
        this.a1 = document.createElement('button');
        this.a1.addEventListener('click', this.h);
        this.a4 = a4;
    }
    h = (e) =>{
        
        console.log(this.a4);
    }
}

class B extends A{
    a2;
    constructor(a4){
        super(a4);
        this.a2 = 4;
    }
}
class C extends B{
    
    constructor(a4){
        super(a4);
    }

    g(){
        return this.a1;
    }
}

// let h = new C(5);
// x.appendChild(h.g());
// h.g().innerText = "hh";

// let a = new C(7);
// console.log(h.g() == a.g())
// x.appendChild(a.g());

// x.addEventListener("mouseenter",s1);
// x.addEventListener("mouseout",s2);

// function s1(e){
//     console.log('in')
//     h.g().disabled = false;
// }
// function s2(e){
//     console.log('out')
//     h.g().disabled = true;
// }