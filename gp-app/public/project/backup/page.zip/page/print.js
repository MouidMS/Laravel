document.addEventListener("DOMContentLoaded", function(event){
    parent();
  });