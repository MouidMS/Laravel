import { currentPage } from "./Page.js";


export default class ComponentList{

    addComponentList ;

    constructor(){
        this.addComponentList = this.prepairAddComponent();
        
    }

    prepairAddComponent(){

                let bPaste = document.createElement('button');
                bPaste.classList.add('mainComponentBtn');
                bPaste.innerText = 'PS';
                bPaste.addEventListener('click', this.copyComponent);

                let bText = document.createElement('button'); 
                bText.dataset.type = "Paragraph";
                bText.classList.add('mainComponentBtn');
                bText.innerText = 'TX';
                bText.addEventListener('click', this.addComponanet);
                
                let bTopic = document.createElement('button');
                bTopic.dataset.type = "Topic";
                bTopic.classList.add('mainComponentBtn');
                bTopic.innerText = 'HD';
                bTopic.addEventListener('click', this.addComponanet);

                let bImage = document.createElement('button');
                bImage.dataset.type = "Image";
                bImage.classList.add('mainComponentBtn');
                bImage.innerText = 'IM';
                bImage.addEventListener('click', this.addComponanet);

                let bIcon = document.createElement('button');
                bIcon.dataset.type = "Icon";
                bIcon.classList.add('mainComponentBtn');
                bIcon.innerText = 'IC';
                bIcon.addEventListener('click', this.addComponanet);

                let bList = document.createElement('button');
                bList.dataset.type = "List";
                bList.classList.add('mainComponentBtn');
                bList.innerText = 'LS';
                bList.addEventListener('click', this.addComponanet);

                let bTable = document.createElement('button');
                bTable.dataset.type = "Table";
                bTable.classList.add('mainComponentBtn');
                bTable.innerText = 'TB';
                bTable.addEventListener('click', this.addComponanet);


                let bTopicList = document.createElement('button');
                bTopicList.dataset.type = "TopicList";
                bTopicList.classList.add('mainComponentBtn');
                bTopicList.innerText = 'TPL';
                bTopicList.addEventListener('click', this.addComponanet);

                let bShape = document.createElement('button');
                bShape.dataset.type = "Shapes";
                bShape.classList.add('mainComponentBtn');
                bShape.innerText = 'SH';
                bShape.addEventListener('click', this.addComponanet);


                let div = document.createElement('div');
                div.style.disply = 'none';
                div.style.width = '100px';
                div.style.height = '100px';
                div.classList.add('addBlock');
                

                div.appendChild(bPaste);
                div.appendChild(bText);
                div.appendChild(bTopic);
                div.appendChild(bList);
                div.appendChild(bTable);
                div.appendChild(bIcon);
                div.appendChild(bImage);
                div.appendChild(bTopicList);
                div.appendChild(bShape);
                return div;
    }
    addComponanet = (e) =>{
        e.stopPropagation();
        let rect = this.getAddComponentList();
        currentPage.addComponanet(e.target.dataset.type,rect.offsetLeft,rect.offsetTop);
    };

    copyComponent = (e) =>{
        e.stopPropagation();
        let rect = this.getAddComponentList();
        currentPage.pasteComponent(rect.offsetLeft,rect.offsetTop);
    }

    getAddComponentList(){
        return this.addComponentList;
    }

}