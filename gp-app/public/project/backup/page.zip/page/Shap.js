// import ParentComponent from "./ParentComponent";



export default class Shap{
    
    constructor(){}
}